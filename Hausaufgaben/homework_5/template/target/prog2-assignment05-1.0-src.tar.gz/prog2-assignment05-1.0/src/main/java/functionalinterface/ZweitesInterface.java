package functionalinterface;

public interface ZweitesInterface<T> {

    boolean compare(T type1, T type2);

}
