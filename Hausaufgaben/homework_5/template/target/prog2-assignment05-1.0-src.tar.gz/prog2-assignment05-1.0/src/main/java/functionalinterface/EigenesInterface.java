package functionalinterface;

public interface EigenesInterface {

    boolean compare(String string1, String string2);

}
