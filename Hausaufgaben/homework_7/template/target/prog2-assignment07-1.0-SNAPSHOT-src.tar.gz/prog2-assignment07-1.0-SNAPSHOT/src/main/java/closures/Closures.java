package closures;

import java.util.Scanner;
import java.util.function.Function;

public class Closures {

    static void greetings(String name){
        // TODO: implement me
    }

    static void welcomeMessage(Function<String, String> greeter){
        // TODO: implement me
    }

    public static void main (String args[]){
        // TODO: implement me
    }
}
