package scala2java;

public class Person2 {

    public String name;
    public int age;

    // Primärer Konstruktor
    public Person2(String name, int age) {
        this.age = age;
        this.name = name;
    }

}
