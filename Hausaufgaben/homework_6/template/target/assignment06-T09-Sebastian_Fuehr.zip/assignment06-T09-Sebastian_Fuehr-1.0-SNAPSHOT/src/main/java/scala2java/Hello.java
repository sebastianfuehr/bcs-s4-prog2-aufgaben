package scala2java;

public class Hello {
}
