package standardfunctionalinterfaces;

public interface ToPrimitiveDoubleBiFunction {

    double applyAsDouble(int i1, int i2);

}
